﻿using Supermodel.Client.CodeGen;
using System;
using System.IO;

namespace ModelGeneratorMVC;

class Program
{
    static void Main()
    {
        var modelGenerator = new ModelGen([typeof(WebMVC.Controllers.XXYXXUserUpdatePasswordController).Assembly]);
        var sb = modelGenerator.GenerateModels();
        var code = sb.ToString();

        File.WriteAllText(@"..\..\..\..\..\Client\BatchApiClientMVC\Supermodel\ModelsForRuntime\Supermodel.Mobile.ModelsForRuntime.cs", code);

        Console.WriteLine("All done!");
    }
}