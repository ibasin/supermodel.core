C:\WINDOWS\system32\netsh.exe http add urlacl url=http://localhost:5001/ user=Everyone
C:\WINDOWS\system32\netsh.exe http add urlacl url=http://10.211.55.9:5001/ user=Everyone

rem pause
